
zb.MaximumHarm = 10
zb.MaxKarma = 150