local MODE = MODE

zb.Points.AZCamera = zb.Points.AZCamera or {}
zb.Points.AZCamera.Color = Color(43,27,222)
zb.Points.AZCamera.Name = "AZCamera Pos"

zb.Points.AZSpawn = zb.Points.AZSpawn or {}
zb.Points.AZSpawn.Color = Color(76,68,169)
zb.Points.AZSpawn.Name = "AZSpawn"