local MODE = MODE

zb = zb or {}

--[[ Идеи
    Слабая зона глаз у комбайнов
    //Убрать возможность комбайнам надевать броню
    //Выдать очки ночного зрения комбайнам ;; Им их выдавать не надо, надо сделать просто функционал встроенный в их класс!!!
    //Аирстрайки у елитовцев
]]

zb = zb or {}
zb.Points = zb.Points or {}

zb.Points.HL2DM_SNIPERSPAWN = zb.Points.HL2DM_SNIPERSPAWN or {}
zb.Points.HL2DM_SNIPERSPAWN.Color = Color(243,9,9)
zb.Points.HL2DM_SNIPERSPAWN.Name = "HL2DM_SNIPERSPAWN"

zb.Points.HL2DM_CROSSBOWSPAWN = zb.Points.HL2DM_CROSSBOWSPAWN or {}
zb.Points.HL2DM_CROSSBOWSPAWN.Color = Color(243,9,9)
zb.Points.HL2DM_CROSSBOWSPAWN.Name = "HL2DM_CROSSBOWSPAWN"