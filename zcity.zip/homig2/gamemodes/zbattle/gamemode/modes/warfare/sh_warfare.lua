local MODE = MODE

zb = zb or {}
zb.Points = zb.Points or {}


zb.Points.HMCD_TDM_TEAM_1 = zb.Points.HMCD_TDM_TEAM_1 or {}
zb.Points.HMCD_TDM_TEAM_1.Color = Color(107, 142, 35)
zb.Points.HMCD_TDM_TEAM_1.Name = "Оливковая команда"

zb.Points.HMCD_TDM_TEAM_2 = zb.Points.HMCD_TDM_TEAM_2 or {}
zb.Points.HMCD_TDM_TEAM_2.Color = Color(244, 164, 96)
zb.Points.HMCD_TDM_TEAM_2.Name = "Песочная команда"

zb.Points.HMCD_TDM_TEAM_3 = zb.Points.HMCD_TDM_TEAM_3 or {}
zb.Points.HMCD_TDM_TEAM_3.Color = Color(0, 0, 0)
zb.Points.HMCD_TDM_TEAM_3.Name = "Черная команда"

zb.Points.HMCD_TDM_TEAM_4 = zb.Points.HMCD_TDM_TEAM_4 or {}
zb.Points.HMCD_TDM_TEAM_4.Color = Color(139, 69, 19)
zb.Points.HMCD_TDM_TEAM_4.Name = "Коричневая команда"
