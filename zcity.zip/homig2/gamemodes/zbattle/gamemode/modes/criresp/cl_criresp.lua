local MODE = MODE
MODE.name = "criresp"
local song
local songfade = 0
net.Receive("criresp_start", function()
	surface.PlaySound("zbattle/criresp.mp3") 

	timer.Simple(3, function()
		sound.PlayFile( "sound/zbattle/criresp/criepmission.mp3", "mono noblock", function( station )
			if ( IsValid( station ) ) then
				station:Play()
				song = station
				songfade = 1
			end
		end )
	end)
end)

local teams = {
	[0] = {
		objective = "Negotiations failed, eliminate the threat. 10-4",
		name = "a SWAT Operator",
		color1 = Color(68, 10, 255),
		color2 = Color(68, 10, 255)
	},
	[1] = {
		objective = "This is my fucking house, bitches, I can do what I want.",
		name = "a Suspect",
		color1 = Color(228, 49, 49),
		color2 = Color(228, 49, 49)
	},
}

function MODE:RenderScreenspaceEffects()
	zb.RemoveFade()
	if zb.ROUND_START + 85 < CurTime() then
		 
		if songfade <= 0.01 and IsValid( song ) then
			song:Stop()
			surface.PlaySound(lply:Team() == 0 and "zbattle/criresp/barricadedsuspectstart.mp3" or "snd_jack_hmcd_policesiren.wav")
		elseif IsValid( song ) then
			songfade = Lerp( 0.01, songfade, 0 )
			song:SetVolume(songfade)
		end
	end
	if zb.ROUND_START + 7.5 < CurTime() then return end
	local fade = math.Clamp(zb.ROUND_START + 7.5 - CurTime(), 0, 1)
	surface.SetDrawColor(0, 0, 0, 255 * fade)
	surface.DrawRect(-1, -1, ScrW() + 1, ScrH() + 1)
end
local posadd = 0
function MODE:HUDPaint()
	if zb.ROUND_START + 90 > CurTime() then
		posadd = Lerp(FrameTime() * 5,posadd or 0, zb.ROUND_START + 7.3 < CurTime() and 0 or -sw * 0.4) 
		local color = Color(255*-math.sin(CurTime()*3),25,255*math.sin(CurTime()*3))
		draw.SimpleText( "SWAT will arrive in: "..string.FormattedTime(zb.ROUND_START + 90 - CurTime(), "%02i:%02i"	), "ZB_HomicideMedium", sw * 0.02 + posadd, sh * 0.95, Color(0,0,0), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText( "SWAT will arrive in: "..string.FormattedTime(zb.ROUND_START + 90 - CurTime(), "%02i:%02i"	), "ZB_HomicideMedium", (sw * 0.02) - 2 + posadd, (sh * 0.95) - 2, color, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		local fade = math.Clamp(zb.ROUND_START + 7.5 - CurTime(), 0, 1)
		surface.SetDrawColor(0, 0, 0, 255 * fade)
		surface.DrawRect(-1, -1, ScrW() + 1, ScrH() + 1)
	end

	if zb.ROUND_START + 8.5 > CurTime() then
		if not lply:Alive() and not lply:Team() == 0 then return end
		local fade = math.Clamp(zb.ROUND_START + 8 - CurTime(), 0, 1)
		local team_ = lply:Team()
		draw.SimpleText("Crisis Response", "ZB_HomicideMediumLarge", sw * 0.5, sh * 0.1, Color(0, 162, 255, 255 * fade), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local Rolename = teams[team_].name
		local ColorRole = teams[team_].color1
		ColorRole.a = 255 * fade
		draw.SimpleText("You are " .. Rolename, "ZB_HomicideMediumLarge", sw * 0.5, sh * 0.5, ColorRole, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		local Objective = teams[team_].objective
		local ColorObj = teams[team_].color2
		ColorObj.a = 255 * fade
		draw.SimpleText(Objective, "ZB_HomicideMedium", sw * 0.5, sh * 0.9, ColorObj, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end

	if hg.PluvTown.Active and fade then
		surface.SetMaterial(hg.PluvTown.PluvMadness)
		surface.SetDrawColor(255, 255, 255, math.random(175, 255) * fade / 2)
		surface.DrawTexturedRect(sw * 0.25, sh * 0.44 - ScreenScale(15), sw / 2, ScreenScale(30))

		draw.SimpleText("SOMEWHERE IN PLUVTOWN", "ZB_ScrappersLarge", sw / 2, sh * 0.44 - ScreenScale(2), Color(0, 0, 0, 255 * fade), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
	end
end

local CreateEndMenu
net.Receive("cri_roundend", function() CreateEndMenu(net.ReadBool()) end)
local colGray = Color(85, 85, 85, 255)
local colRed = Color(130, 10, 10)
local colRedUp = Color(160, 30, 30)
local colBlue = Color(10, 10, 160)
local colBlueUp = Color(40, 40, 160)
local col = Color(255, 255, 255, 255)
local colSpect1 = Color(75, 75, 75, 255)
local colSpect2 = Color(255, 255, 255)
local colorBG = Color(55, 55, 55, 255)
local colorBGBlacky = Color(40, 40, 40, 255)
local blurMat = Material("pp/blurscreen")
local Dynamic = 0
BlurBackground = BlurBackground or hg.DrawBlur

if IsValid(hmcdEndMenu) then
	hmcdEndMenu:Remove()
	hmcdEndMenu = nil
end

CreateEndMenu = function(whowin)
	if IsValid(hmcdEndMenu) then
		hmcdEndMenu:Remove()
		hmcdEndMenu = nil
	end

	Dynamic = 0
	hmcdEndMenu = vgui.Create("ZFrame")
	surface.PlaySound( (whowin == 1) and "zbattle/criresp/failedSWAT.mp3" or "ambient/alarms/warningbell1.wav")
	local sizeX, sizeY = ScrW() / 2.5, ScrH() / 1.2
	local posX, posY = ScrW() / 1.3 - sizeX / 2, ScrH() / 2 - sizeY / 2
	hmcdEndMenu:SetPos(posX, posY)
	hmcdEndMenu:SetSize(sizeX, sizeY)
	--hmcdEndMenu:SetBackgroundColor(colGray)
	hmcdEndMenu:MakePopup()
	hmcdEndMenu:SetKeyboardInputEnabled(false)
	hmcdEndMenu:ShowCloseButton(false)
	local closebutton = vgui.Create("DButton", hmcdEndMenu)
	closebutton:SetPos(5, 5)
	closebutton:SetSize(ScrW() / 20, ScrH() / 30)
	closebutton:SetText("")
	closebutton.DoClick = function()
		if IsValid(hmcdEndMenu) then
			hmcdEndMenu:Close()
			hmcdEndMenu = nil
		end
	end

	closebutton.Paint = function(self, w, h)
		surface.SetDrawColor(122, 122, 122, 255)
		surface.DrawOutlinedRect(0, 0, w, h, 2.5)
		surface.SetFont("ZB_InterfaceMedium")
		surface.SetTextColor(col.r, col.g, col.b, col.a)
		local lenghtX, lenghtY = surface.GetTextSize("Close")
		surface.SetTextPos(lenghtX - lenghtX / 1.1, 4)
		surface.DrawText("Close")
	end

	hmcdEndMenu.PaintOver = function(self, w, h)
		surface.SetFont("ZB_InterfaceMediumLarge")
		surface.SetTextColor(col.r, col.g, col.b, col.a)
		local lenghtX, lenghtY = surface.GetTextSize("Players:")
		surface.SetTextPos(w / 2 - lenghtX / 2, 20)
		surface.DrawText("Players:")
	end

	-- PLAYERS
	local DScrollPanel = vgui.Create("DScrollPanel", hmcdEndMenu)
	DScrollPanel:SetPos(10, 80)
	DScrollPanel:SetSize(sizeX - 20, sizeY - 90)

	for i, ply in player.Iterator() do
		if ply:Team() == TEAM_SPECTATOR then continue end
		local but = vgui.Create("DButton", DScrollPanel)
		but:SetSize(100, 50)
		but:Dock(TOP)
		but:DockMargin(8, 6, 8, -1)
		but:SetText("")
		but.Paint = function(self, w, h)
	local col1 = (ply:Alive() and colRed) or colGray
	local col2 = (ply:Alive() and colRedUp) or colSpect1
	surface.SetDrawColor(col1.r, col1.g, col1.b, col1.a)
	surface.DrawRect(0, 0, w, h)
	surface.SetDrawColor(col2.r, col2.g, col2.b, col2.a)
	surface.DrawRect(0, h / 2, w, h / 2)
	local col = ply:GetPlayerColor():ToColor()
	surface.SetFont("ZB_InterfaceMediumLarge")
	local lenghtX, lenghtY = surface.GetTextSize(ply:GetPlayerName() or "He quited...")
	surface.SetTextColor(0, 0, 0, 255)
	surface.SetTextPos(w / 2 + 1, h / 2 - lenghtY / 2 + 1)
	surface.DrawText(ply:GetPlayerName() or "He quited...")
	surface.SetTextColor(col.r, col.g, col.b, col.a)
	surface.SetTextPos(w / 2, h / 2 - lenghtY / 2)
	surface.DrawText(ply:GetPlayerName() or "He quited...")
	local col = colSpect2
	surface.SetFont("ZB_InterfaceMediumLarge")
	surface.SetTextColor(col.r, col.g, col.b, col.a)
	local lenghtX, lenghtY = surface.GetTextSize(ply:GetPlayerName() or "He quited...")
	surface.SetTextPos(15, h / 2 - lenghtY / 2)
	surface.DrawText(ply:Name() .. (ply:GetNetVar("handcuffed", false) and " - neutralized" or (not ply:Alive() and " - dead") or ""))
	surface.SetFont("ZB_InterfaceMediumLarge")
	surface.SetTextColor(col.r, col.g, col.b, col.a)
	local lenghtX, lenghtY = surface.GetTextSize(ply:Frags() or "He quited...")
	surface.SetTextPos(w - lenghtX - 15, h / 2 - lenghtY / 2)
	surface.DrawText(ply:Frags() or "He quited...")
end


		function but:DoClick()
			if ply:IsBot() then
				chat.AddText(Color(255, 0, 0), "no, you can't")
				return
			end

			gui.OpenURL("https://steamcommunity.com/profiles/" .. ply:SteamID64())
		end

		DScrollPanel:AddItem(but)
	end
	return true
end

function MODE:RoundStart()
	if IsValid(hmcdEndMenu) then
		hmcdEndMenu:Remove()
		hmcdEndMenu = nil
	end
end

