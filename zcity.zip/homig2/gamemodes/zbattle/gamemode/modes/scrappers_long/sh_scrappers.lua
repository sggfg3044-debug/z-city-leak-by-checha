local MODE = MODE

MODE.StartingMoney = 1000