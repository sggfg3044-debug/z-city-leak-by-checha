local MODE = MODE

zb = zb or {}
zb.Points = zb.Points or {}

zb.Points.HMCD_SWO_WAGNER = zb.Points.HMCD_SWO_WAGNER or {}
zb.Points.HMCD_SWO_WAGNER.Color = Color(25,95,0)
zb.Points.HMCD_SWO_WAGNER.Name = "HMCD_SWO_WAGNER"

zb.Points.HMCD_SWO_AZOV = zb.Points.HMCD_SWO_AZOV or {}
zb.Points.HMCD_SWO_AZOV.Color = Color(100,75,0)
zb.Points.HMCD_SWO_AZOV.Name = "HMCD_SWO_AZOV"

zb.Points.HMCD_SWO_CAPPOINT = zb.Points.HMCD_SWO_CAPPOINT or {}
zb.Points.HMCD_SWO_CAPPOINT.Color = Color(100,75,0)
zb.Points.HMCD_SWO_CAPPOINT.Name = "HMCD_SWO_CAPPOINT"