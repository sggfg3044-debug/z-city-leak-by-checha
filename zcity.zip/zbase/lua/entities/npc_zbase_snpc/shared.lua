AddCSLuaFile()

ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.PrintName		= "SNPC"
ENT.Author			= "Zippy"