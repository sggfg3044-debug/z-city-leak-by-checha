AddCSLuaFile()
AddCSLuaFile("cl_init.lua")

ENT.Base =      "base_gmodentity"
ENT.Type =      "anim"
ENT.Author =    "Zippy"
ENT.PrintName = "NPC Spawner"
ENT.Spawnable = false
ENT.Category =  "ZBase"