AddCSLuaFile()
AddCSLuaFile("cl_init.lua")

ENT.Base = "base_ai"
ENT.Type = "ai"
ENT.PrintName		= "ZBase Navigator"
ENT.Author			= "Zippy"
ENT.AutomaticFrameAdvance = false