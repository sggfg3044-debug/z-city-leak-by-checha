-- NPC FOR TESTING

local NPC = FindZBaseTable(debug.getinfo(1,'S'))