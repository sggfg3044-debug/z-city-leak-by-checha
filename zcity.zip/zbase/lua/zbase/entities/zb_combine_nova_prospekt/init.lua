local NPC = FindZBaseTable(debug.getinfo(1,'S'))

NPC.StartHealth = 60 -- Max health
NPC.Models = {"models/Combine_Soldier_PrisonGuard.mdl"}