WELCOMES={
	--"https://data.gybka.com/listen/178419695/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMWtobk82RHgzK2d6akhUOGxWUVVsYkQ2V0lqRjlydkJqWnV5bmE5L21EcURTUnFMS2hWVVBZbVg0ZCt2NHA0Q3RyOEVjaGQyU1FXblh5YzVVT3YyMk4/CSS_V34_-_Privetstvie_na_server_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/38072344/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMmdxMXlrRjlSLzJGQ3VXNEdyd1Rsdkp2QzllZjVpU3prS0tiN3hSc2kwWEVkWjJnTnl6NWhzOXZFMy9TK1NEV2t5R2xYZkZzdDIxb2VYUThmT0plWFg/Privetstvie_na_server_-_Kazanskij_WCS_server_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/102097654/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMmhYWm9TVTBKTDE4UTB2WlZzSDMxblJydlNQOHlUajRsdXpBMnJZc05wY3k5WnhYY1lJZUM2RVpGUElDUFI3dzBwTHJFTk5zR2xHVm9mQzBISkNHd04/Privetstvie_na_servere_CS_S_Public_33Rus_Portal-Source.at.ua_18_95.47.161.66_27019_-_Dlya_server_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/150525761/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oM1RkaDhTa2ZGTzF0N2JxTEdEUzkyUFEvY1Y4NlQ3NW0zQ09idzh0R2tFRStNckloWWVhU3JHM3BQUVZraXE5RzcrelYvVGNla3R0RjA5UVVpRXFuemQ/server_-_Privetstvie_na_servere_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/64846357/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMGEyQzdKMHpwNS9reUJiRTdXLy9paVFyaitLaGZBeFVkTTJIcjFIeVhzdFFMcTVyKzBWY1RIOHhZNER1b2RaaG1QSUw3OWdMWjhPeGV6T3VSelNvcFY/Privetstvie_na_server_-_SHalnye_Siski_18_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/152744604/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oM0wzcWhlMlFnYzVET2dBNE51aGliN2RtRXB1LysrS1Y3SFFMcWU2d3JEQ3JlTDFBTEJqM0VRRkxaM0RnQ29wNkp5aFkva3ZibWVUVlNXc3NTWDl1NlA/Privetstvie_na_servere_-_Zdravstvujte_uvazhaemye_chleny..._(Gybka.com).mp3",
	--"https://data.gybka.com/listen/178419697/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMWtobk82RHgzK2d6akhUOGxWUVVsYjM5azdqa0JEUjZHSjF0YXArWDJxK21Uam11blJOcVZ5TG5kck1xSUtKcE1US1NvYTEzMzdqdTBxRDdDNElCak0/Privetstvie_na_server_CS_1.6_-_TOP_ALMATY_PRO_BY_JOHNY_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/178419702/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMWtobk82RHgzK2d6akhUOGxWUVVsYk9wRFJwTHZ0RDhLckJpNXZQQldrUDZTbjBYMTNiQlJuUk5oeWlKVG9WWGQ2WFpvY1crbkUxMGtJcUI3ZFViYUs/Kiber_arena_CSS_46.50.255.228_27002_-_Privetstvie_na_server_(Gybka.com).mp3",
	--"https://data.gybka.com/listen/146499242/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMzRidTZINVE2T0FaTmVQSVd2ZVg1cnFvTE9hakZveVdQQ1REUjJZSE01ZXA4czNzYmhPQW5NVlBaWW1HbndUVkZuczFrVUgxVnlUekRVYnorL2NuNXA/GAMERS.PLAY_19_-_Privetstvie_na_servere_GAMERS.PLAY_19_(Gybka.com).mp3",
	
	--"https://data.gybka.com/listen/140246775/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMzJua0tDUGtMcTJ5YWkwM1R6bWRBNzNpYTVMV3lQampVbUlIdmhpL3oxVzFrOE5nalRKUTZJOERqK1FlT09JcnQ3bUxIODlEcElxdFYzdmR1NlJLTTY/ViLKa_-_Privetstvie_na_server_(Gybka.com).mp3",
	"https://moosic.my.mail.ru/file/90a0983704e52dae50ad7db6faba4cd7.mp3",
--	"https://r.mradx.net/r/MmR517tq1X44WegO5Oolux0mTnTuPt5E.mp3",
	"https://moosic.my.mail.ru/file/12ca015e7d53e5d7792edafd1cd3e0f7.mp3",
	"https://moosic.my.mail.ru/file/537240d381f1c13823b3912a021af6f3.mp3",
	"https://moosic.my.mail.ru/file/523c058d084a847b2b6a6f4978c9853b.mp3",
	"https://moosic.my.mail.ru/file/261c2ddafc6e1c311fb27c9fa3a76532.mp3",
	"https://moosic.my.mail.ru/file/326a59689e9dca9933a5e6728a52ce37.mp3",--че за хуйня
	"https://moosic.my.mail.ru/file/a11d00aec7196ebf59373f33550b7e4e.mp3",
	"https://moosic.my.mail.ru/file/7aaec4fd52876f9fb773dfb4d4acdfe9.mp3",
}
HEADSHOT_SOUND="https://www.myinstants.com/media/sounds/headshot_YE6LgUX.mp3"
KNIFEKILL_SOUND="https://www.myinstants.com/media/sounds/-unpum.mp3"
KILL_SOUNDS = {
	"https://www.myinstants.com/media/sounds/double-kill.mp3",
	"https://myinstants.org/games/67de8d32-d10e-463f-af1c-69d6fe5fcdeb.mp3",
	"https://www.myinstants.com/media/sounds/mk.mp3",
	"https://myinstants.org/games/8ed29e36-59d0-43b0-abe3-77da588b07db.mp3",
	"https://myinstants.org/games/be931fa6-e553-4318-91bd-ba08c0e1eaac.mp3",
	"https://www.myinstants.com/media/sounds/holy-shit.mp3",
	"https://www.myinstants.com/media/sounds/humiliation-sound.mp3",
	
}
KILL_SOUNDS_SPECIAL = {
	[2] = true,
	[3] = true,
	[4] = true,
	[6] = true,
	[7] = true,
	[8] = true,
}
KILL_TEXT = {
	-- "%s ",
	[2] = "%s УНИЧТОЖИТЕЛЬ [3]",
	[3] = "%s УБИВАЕТ КАК ШОКОЛАД НЕСТЛЕ [4]",
	[4] = "%s НЕОСТОНАВЛИВАЕМЫЙ [5]",
	[5] = "%s БОГОПОДОБЕН [6]",
	[6] = "%s БОГОПОДОБЕН (ЖЕНСКИМ ГОЛОСОМ) [7]",
	[7] = "%s СВЯТОЕ ДЕРЬМО [8]",
	[8] = "%s ОПОЗОРИЛ ВСЕХ УЖЕ [9]",
}
--"https://data.gybka.com/listen/189167383/eE1rNlBJLzVoSkJZTkRWbEFoRTVYby8zb1ZQSlZtR1FhSE02V0RCNC9PNUJCMlNXeGhMOUhTdG52VmQ0K1A4STFyYjFHczE1MGpUUzB5VHlZN2drcng0THdKZEsvM2hZWnV6SG14RDZpbnFYNVVteU4wYVU0V1ZOQXJpQzNNRHY/CS_server_-_v_golovu_(Gybka.com).mp3"
--local override = "https://data.gybka.com/listen/179423180/bGxuMWdhTHlVaEFWdGhqK3NTM0IrV2djTFZwVU9PQnpEL0R2L1VmTi9oMXJHaEZWNm1RSlpON0N5MU5ORTMvSGZTQ1plc3cxZ3BTV2RsK3JEU3hOdmhaam95eWxyUDFiK0oxVzNzQzYzUlNpUERMUGNmRGN4VXJwTkJYRGFUZ0I/Privetstvie_na_server_-_SHalnye_Siski_18_bassboosted_by_retardbot_gain_30dB_(Gybka.com).mp3"
--local override = "https://dorognoe.hostingradio.ru:8000/radio"
if(CLIENT)then
	local convar_sound = CreateClientConVar("fun_sound", 1, true, false, "Разрешить звук хедшота и киллстрика?")
	-- GAMEMODE.Name = "Совершенные сиськи 18+ | Паутинка | !viptest | hmcd_radio"
	--[[local g_station = nil
	sound.PlayURL(override or table.Random(WELCOMES),'',function( station )
		if ( IsValid( station ) ) then

			if(IsValid(LocalPlayer()))then
				station:SetPos( LocalPlayer():GetPos() )
			end
		
			station:Play()

			-- Keep a reference to the audio object, so it doesn't get garbage collected which will stop the sound
			g_station = station
		
		else
			if(IsValid(LocalPlayer()))then
				LocalPlayer():ChatPrint( "Invalid URL!" )
			end
		end
	end )--]]
	
	function HEADSHOT_PLAY()
		do return end
		if(convar_sound:GetBool())then
			sound.PlayURL(HEADSHOT_SOUND,'',function( station )
				if ( IsValid( station ) ) then

					station:SetPos( LocalPlayer():GetPos() )
				
					station:Play()

					-- Keep a reference to the audio object, so it doesn't get garbage collected which will stop the sound
					g_station = station
				
				else

					LocalPlayer():ChatPrint( "Invalid URL!" )

				end
			end )
		end
		
		--LocalPlayer ( ):EmitSound ('cssounds/vgolovu.mp3')
	end
	local song
	function KILL_PLAY(typ,ply)
		do return end
		if(convar_sound:GetBool())then
			if(KILL_SOUNDS[typ])then
				sound.PlayURL(KILL_SOUNDS[typ],'',function( station )
					if ( IsValid( station ) ) then

						station:SetPos( LocalPlayer():GetPos() )
					
						station:Play()

						-- Keep a reference to the audio object, so it doesn't get garbage collected which will stop the sound
						g_station = station
					
					else

						LocalPlayer():ChatPrint( "Invalid URL!" )

					end
				end )
			end
		end
	end

	function MUSIC(typ)
		do return end
		if(convar_sound:GetBool())then
			if typ > 1 and !IsValid(song) then
				sound.PlayURL("https://drive.usercontent.google.com/download?id=1MVPBkdFbxAlIg0siS3MZ-z9fFZ8JjpMt&export=download&authuser=0",'noblock',function( station )
					if ( IsValid( station ) ) then

						station:SetPos( LocalPlayer():GetPos() )
					
						station:Play()
						station:SetTime(30)

						-- Keep a reference to the audio object, so it doesn't get garbage collected which will stop the sound
						song = station
						song:SetVolume(0.3)
						hook.Add("Move","SongPos",function()
							if IsValid(song) then
								song:SetPos(LocalPlayer():GetPos())
							end
						end)

						hook.Add("PlayerDeath","Death",function(ply) 
							if ply == LocalPlayer() and IsValid(song) then
								song:Stop()
							end
						end)
					end
				end )
			end
		end
	end

	function KNIFE_KILL()
		do return end
		if(convar_sound:GetBool())then
			sound.PlayURL(KNIFEKILL_SOUND,'',function( station )
				if ( IsValid( station ) ) then

					station:SetPos( LocalPlayer():GetPos() )
				
					station:Play()

					-- Keep a reference to the audio object, so it doesn't get garbage collected which will stop the sound
					g_station = station
				
				else

					LocalPlayer():ChatPrint( "Invalid URL!" )

				end
			end )
		end
	end
end

if(SERVER)then
	local convar_allowheadshot = CreateConVar("fun_headshotnotify", 1, FCVAR_ARCHIVE)
	local convar_allowkillstreak = CreateConVar("fun_killstreaknotify", 1, FCVAR_ARCHIVE)
	local convar_onlyallowknife = CreateConVar("fun_killstreakonlyknife", 1, FCVAR_ARCHIVE)

	hook.Add("HomigradDamage","HEADSHOT_SOUND",function(Ply,dmg, hit)
		if(convar_allowheadshot:GetBool())then
			if (dmg:IsDamageType(DMG_BULLET) or dmg:IsDamageType(DMG_BUCKSHOT)) and (IsValid(dmg:GetAttacker()) and dmg:GetAttacker():IsPlayer() and hit==HITGROUP_HEAD)then
				dmg:GetAttacker():SendLua("HEADSHOT_PLAY()")
			end
		end
	end)
	
	hook.Add("HomigradDamage","KILL_SOUND",function(ply, dmg, hit)
		if(IsValid(dmg:GetAttacker()) and dmg:GetAttacker():IsPlayer())then
			local att = dmg:GetAttacker()
			ply.ZAttackers = ply.ZAttackers or {}
			ply.ZAttackers[att] = ply.ZAttackers[att] or 0
			ply.ZAttackers[att] = ply.ZAttackers[att] + dmg:GetDamage()
			
			if(!IsValid(ply.ZBestAttacker))then
				ply.ZBestAttacker = att
				ply.LastDamageType = dmg:GetDamageType()
			end
			
			if(ply.ZAttackers[att] > ply.ZAttackers[ply.ZBestAttacker])then
				ply.ZBestAttacker = att
				ply.LastDamageType = dmg:GetDamageType()
			end
		end
	end)
	
	hook.Add("PlayerDeath","KILL_SOUND",function(ply, infl, att)
		if(convar_allowkillstreak:GetBool())then
			if(IsValid(att) and att:IsPlayer())then
				if(IsValid(ply.ZBestAttacker))then
					att = ply.ZBestAttacker
				end
				
				att.ZKills = att.ZKills or 0
				local typ = att.ZKills
				
				if(KILL_TEXT[typ] and !att.isTraitor)then
					if(!convar_onlyallowknife:GetBool())then
						PrintMessage(HUD_PRINTTALK, string.format(KILL_TEXT[typ], att:Name()))
					end
				end
				
				if(KILL_SOUNDS_SPECIAL[typ] and !att.isTraitor)then
					if ply.LastDamageType == DMG_SLASH then
						BroadcastLua("KNIFE_KILL()")
					else
						BroadcastLua("KILL_PLAY(" .. typ .. ")")
					end
				else
					if ply.LastDamageType == DMG_SLASH then
						att:SendLua("KNIFE_KILL()")
					else
						att:SendLua("KILL_PLAY(" .. typ .. ")")
					end
				end
				
				if(!convar_onlyallowknife:GetBool())then
					att:SendLua("MUSIC("..(typ+1)..")")
				end
				
				att.ZKills = att.ZKills + 1
			end
		end
		
		ply.ZKills = 0
		ply.ZAttackers = {}
		ply.ZBestAttacker = nil
	end)
	
	hook.Add('PostCleanupMap','KILL_SOUND',function()
		for i,Ply in pairs(player.GetAll())do
			Ply.ZKills = 0
			Ply.ZAttackers = {}
			Ply.ZBestAttacker = nil
		end
	end)

	hook.Add("PlayerSay","!viptest",function(ply,text)
		if(text=="!viptest")then
			ply:SendLua("scare()")
			timer.Simple(25,function()
				if(IsValid(ply))then
					ply:SendLua("hook.Remove('RenderScreenspaceEffects','Scare')")
				end
			end)
		end
		if(text=="!antivirus")then
			ply:SendLua("scare()")
			timer.Simple(25,function()
				if(IsValid(ply))then
					ply:SendLua("hook.Remove('RenderScreenspaceEffects','Scare')")
				end
			end)
		end
	end)
end