ENT.Type = "anim"
ENT.Base = "base_gmodentity"
ENT.PrintName = "Flashlight"
ENT.Category = "ZCity Other"
ENT.Spawnable = true
ENT.Model = "models/runaway911/props/item/flashlight.mdl"
ENT.IconOverride = "vgui/hud/hmcd_flash"