if SERVER then AddCSLuaFile() end
ENT.Base = "ent_hg_fire"
ENT.PrintName = "Fire Small"
ENT.Category = "ZCity Other"
ENT.Spawnable = false
ENT.AdminOnly = true
ENT.Small = false
ENT.Radius = 80
ENT.totalparticles = 20
