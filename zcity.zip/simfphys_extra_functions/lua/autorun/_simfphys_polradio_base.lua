--DO NOT REUPLOAD THIS FILE. COPY IT AND MODIFY IT TO YOUR NEEDS.
--Rename the copied file, but be sure to keep the _ in front of the name, so that it is loaded BEFORE your vehicles

sound.Add( {
	name = "Simf_PolRadio", --RENAME your radio here
	channel = CHAN_STATIC, --DO NOT MODIFY
	volume = 1.0, --DO NOT MODIFY
	level = 110, --DO NOT MODIFY
	pitch = { 100 }, --DO NOT MODIFY
	sound = { --ADD your sounds here, as a list
		"vehicles/polradio/polradio1.mp3",
		"vehicles/polradio/polradio2.mp3",
		"vehicles/polradio/polradio3.mp3",
		"vehicles/polradio/polradio4.mp3",
		"vehicles/polradio/polradio5.mp3",
		"vehicles/polradio/polradio6.mp3",
		"vehicles/polradio/polradio7.mp3",
		"vehicles/polradio/polradio8.mp3",
		"vehicles/polradio/polradio9.mp3",
		"vehicles/polradio/polradio10.mp3",
		"vehicles/polradio/polradio11.mp3",
		"vehicles/polradio/polradio12.mp3",
		"vehicles/polradio/polradio13.mp3",
		"vehicles/polradio/polradio14.mp3",
		"vehicles/polradio/polradio15.mp3",
		"vehicles/polradio/polradio16.mp3",
		"vehicles/polradio/polradio17.mp3",
	},
} )